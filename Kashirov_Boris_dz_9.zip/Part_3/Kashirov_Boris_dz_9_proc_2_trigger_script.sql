DROP TRIGGER IF EXISTS shop.my_null_trigger_2;
USE shop;

DELIMITER $$
$$
CREATE DEFINER=`root`@`localhost` TRIGGER `my_null_trigger_2` BEFORE INSERT ON `products` FOR EACH ROW begin 
	if(isnull(new.name) and isnull(new.description)) then 
	signal sqlstate '45000' set message_text = 'Оба поля не могут быть нулевыми';
	end if;
end$$
DELIMITER ;